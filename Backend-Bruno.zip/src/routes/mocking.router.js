import express from 'express';
import { generatePets, generateUsers } from '../utils/mocking.js';
import Users from '../dao/Users.dao.js';
import petModel from '../dao/models/pet.js';

const router = express.Router();
const usersDao = new Users();

// Endpoint to generate mocking pets
router.get('/mockingpets', (req, res) => {
    const pets = generatePets(100);
    res.status(200).json({ pets });
});

// Endpoint to generate mocking users
router.get('/mockingusers', async (req, res) => {
    try {
        const users = generateUsers(50);
        res.status(200).json({ users });
    } catch (error) {
        res.status(500).json({ message: 'Error generating users', error });
    }
});

// Endpoint to generate and insert data
router.post('/generateData', async (req, res) => {
    const { users, pets } = req.body;

    try {
        // Generate users and pets
        const generatedUsers = generateUsers(users);
        const generatedPets = generatePets(pets);

        // Insert users and pets into the database
        await usersDao.save(generatedUsers);
        await petModel.insertMany(generatedPets);

        res.status(201).json({ message: 'Data generated and inserted successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error generating and inserting data', error });
    }
});

export default router;
